# Лабораторная работа №05
## Тема: Доработка контракта, Верификация (BSC Testnet)

### Цель:
Научиться дорабатывать смарт‑контракт ERC-20, реализовать ограничения на функцию mint, развернуть контракт в BNB Smart Chain Testnet и выполнить его верификацию.

## Используемые инструменты
- Remix IDE
- MetaMask
- OpenZeppelin Contracts
- Solidity 0.8.20
- BNB Smart Chain Testnet
- BscScan Testnet

## Описание выполненной работы

### Реализована функция mint:
- Только владелец может выполнять mint (onlyOwner)
- Максимальная эмиссия: 1 000 000 MTK

### Данные токена:
- Name: MyToken
- Symbol: MTK
- Decimals: 18

### Контракт развернут в BSC Testnet
Адрес: 0xCBaAdbc9f228B038cD4d81A55bD489B33480B1b2

### Контракт верифицирован
Верификация выполнена через BscScan Testnet.

### Mint выполнен
Токены успешно выпущены и добавлены в MetaMask.

## Структура проекта
```
/contract
    MyToken.sol
/screenshots
    (сюда добавить скриншоты)
Отчет_по_токену_MTK.docx
README.md
```

## Код контракта
(файл MyToken.sol в папке contract)

## Ссылки

Контракт в BscScan Testnet:  
https://testnet.bscscan.com/address/0xCBaAdbc9f228B038cD4d81A55bD489B33480B1b2
